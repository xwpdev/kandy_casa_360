package com.example.kandy_casa_360

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
